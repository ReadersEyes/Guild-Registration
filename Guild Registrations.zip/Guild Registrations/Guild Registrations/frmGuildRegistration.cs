﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guild_Registrations
{
    public partial class frmGuildRegistration : Form
    {
        public frmGuildRegistration()
        {
            InitializeComponent();
        }

        private void frmGuildRegistration_Load(object sender, EventArgs e)
        {
           panel1.BackColor = Color.FromArgb(100,0,0,0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //record button to pre
            frmMemberList memberList = new frmMemberList();
            memberList.ShowDialog();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.ShowDialog();
        }
    }
}
