﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Guild_Registrations
{
    public partial class frmMemberList : Form
    {
        public frmMemberList()
        {
            InitializeComponent();
        }

        private void frmMemberList_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(100, 0, 0, 0);

            listView1.View = View.Details;
            listView1.GridLines = true;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmGuildRegistration guildRegistration = new frmGuildRegistration();
            guildRegistration.ShowDialog();

            
        }

      
    }
}
